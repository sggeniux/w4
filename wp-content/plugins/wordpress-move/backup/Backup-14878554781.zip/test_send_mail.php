<?php

mail('simon.gourfink@geniux.design', 'test cron gandi', 'le message a été envoyé');

?>